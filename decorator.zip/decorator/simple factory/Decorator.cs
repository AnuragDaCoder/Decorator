﻿

namespace decoratorpattern
{
    public interface IMailService
    {
        void sendEmail(string message);
    }

    public class OnPremiseEmailService : IMailService
    {
        public void sendEmail(string message)
        {
            Console.WriteLine("OnPremiseEmailService ::"+message);
        }
    }

    public class AzureCloudEmailService : IMailService
    {
        public void sendEmail(string message)
        {
            Console.WriteLine("AzureCloudEmailService ::" + message);
        }
    }


    //its like a base wrapper
    public class MailDecoratorService : IMailService
    {
        private readonly IMailService _mailService;

        public MailDecoratorService(IMailService mailService)
        {
            _mailService = mailService;
        }

        public virtual void sendEmail(string message)
        {
            _mailService.sendEmail(message);
        }
    }

    public class AnalyticsDecoratorService : MailDecoratorService
    {
        public AnalyticsDecoratorService(IMailService mailService) : base(mailService)
        {
        }

        public override void sendEmail(string message)
        {
            //do some extra stuff here 
            Console.WriteLine("inside AnalyticsDecoratorService");
            base.sendEmail(message);
        }
    }

}
