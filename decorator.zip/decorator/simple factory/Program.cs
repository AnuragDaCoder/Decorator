﻿// See https://aka.ms/new-console-template for more information



using decoratorpattern;

var premiseObj = new OnPremiseEmailService();
premiseObj.sendEmail("premise email service");


var azureServObj = new AzureCloudEmailService();
azureServObj.sendEmail("azure email service");

var analyticsDecObj = new AnalyticsDecoratorService(azureServObj);
analyticsDecObj.sendEmail("analyticsDecorator service");